import { atom } from "recoil";

export const selectedTradeTabState = atom({
    key: "selectedTradeTabState",
    default: "",
});