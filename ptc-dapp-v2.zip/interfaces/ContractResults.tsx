interface StakingDataType {
    stakedAmount : BigInt;
    stakeTime : BigInt;
    isStaked: boolean;
}


export default StakingDataType;