interface Option {
    text: string;
    value: string;
    image: string;
    icon: string;
    address: string;
    decimals: number;
  }


export default Option;